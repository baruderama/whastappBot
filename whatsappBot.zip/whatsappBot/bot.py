import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os,time

driver = webdriver.Firefox()

driver.get("https://web.whatsapp.com/")
time.sleep(10)

celular= "573103025949"
mensaje= "hola bro"

driver.get("https://wa.me/"+celular+"?text="+mensaje)
time.sleep(10)




btn=driver.find_element_by_xpath("//*[@id='action-button']")
btn.click()
time.sleep(10)
btn=driver.find_element_by_xpath("//*[@id='fallback_block']/div/div/a")[0]
btn.click()
time.sleep(3)

driver.close()

#print(pd.__version__)

#file = pd.ExcelFile('phoneNumbers.xls')

#print(file)

#infoExcel=pd.read_excel('phoneNumbers.xls', index_col=0,usecols="A:B")

#print(infoExcel.values.tolist())

#lista=infoExcel.values.tolist()

#for i in lista :
#    print(i)







#pd.read_excel('phoneNumbers.xlsx')